# Zing (Android controller)

Visible app, used to control phones running Bytello.

- Set the ntfy topic and server (default `nlm69` on `https://ntfy.sh`; must match the Bytello phones).
- **Groups**: create a group with any name you like (e.g. "Oppo", "Vivo", "Living room"). Tap a
  group to expand it and see its devices.
- **Devices**: inside an expanded group, add devices by the exact name they were given in Bytello.
  Each device shows **Start** and **Stop** buttons.
- **Options**: tap "Options" on a device to reveal its ring settings:
  - Duration per ring (seconds, blank = ring until stopped)
  - Repeat (spam) toggle — keeps ringing after each gap until stopped
  - Delay between repeats (seconds, used only when spam is on)
  These are remembered per device and reused the next time you tap Start.
- **Stop** always sends a plain stop, no settings needed.

Everything (topic, server, groups, devices, their settings) is saved on the phone and is still
there the next time you open the app.
