package com.example.ntfyalarm

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var topicInput: EditText
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 2000)
        }
    }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startListener() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        topicInput = findViewById(R.id.topic)
        status = findViewById(R.id.status)

        topicInput.setText(prefs().getString(NtfyAlarmService.KEY_TOPIC, ""))

        findViewById<Button>(R.id.btnSave).setOnClickListener { saveTopic() }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!saveTopic()) return@setOnClickListener
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                startListener()
            }
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(Intent(this, NtfyAlarmService::class.java).setAction(NtfyAlarmService.ACTION_STOP))
        }
        findViewById<Button>(R.id.btnDnd).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<Button>(R.id.btnBattery).setOnClickListener { openBatterySettings() }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun prefs() = getSharedPreferences(NtfyAlarmService.PREFS, Context.MODE_PRIVATE)

    private fun saveTopic(): Boolean {
        val topic = topicInput.text.toString().trim()
        if (!Regex("^[A-Za-z0-9_-]{1,64}$").matches(topic)) {
            Toast.makeText(this, "Topic: 1-64 chars, letters, digits, _ or -", Toast.LENGTH_LONG).show()
            return false
        }
        prefs().edit().putString(NtfyAlarmService.KEY_TOPIC, topic).apply()
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun startListener() {
        // Restart so a changed topic takes effect.
        if (NtfyAlarmService.running) {
            startService(Intent(this, NtfyAlarmService::class.java).setAction(NtfyAlarmService.ACTION_STOP))
            handler.postDelayed({ launchService() }, 600)
        } else {
            launchService()
        }
    }

    private fun launchService() {
        ContextCompat.startForegroundService(
            this, Intent(this, NtfyAlarmService::class.java).setAction(NtfyAlarmService.ACTION_START)
        )
    }

    private fun openBatterySettings() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Already exempt from battery optimization", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun refresh() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val svc = when {
            !NtfyAlarmService.running -> "stopped"
            NtfyAlarmService.connected -> "connected"
            else -> "connecting / retrying"
        }
        val dnd = if (nm.isNotificationPolicyAccessGranted) "granted" else "NOT granted"
        val batt = if (pm.isIgnoringBatteryOptimizations(packageName)) "exempt" else "optimized (may be killed)"
        status.text = "Listener: $svc\nDND access: $dnd\nBattery: $batt"
    }
}
