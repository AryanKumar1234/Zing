# Bytello (Android receiver)

No interface. Open the app once: it asks for a device name, then the needed permissions,
starts listening to the ntfy topic `nlm69` (change `"nlm69"` in `ListenService.kt` for another
topic) and closes itself. The launcher icon hides itself once setup is complete.

A persistent notification, "Bytello service running in background" (no subtext, plain dot icon),
stays in the status bar while it runs — Android requires this for a background listener and it
cannot be removed, only kept quiet, which it already is (low priority, silent).

Commands (sent as the ntfy message):
- `/start <device name> [durationSec] [spam:y|n] [delaySec]`
  - `durationSec`: how long one ring lasts. Blank or 0 = ring until stopped (capped at 10 minutes),
    unless spam is on, where 0 means a 10-second ring.
  - `spam`: `y` repeats the ring after each gap until `/stop` is sent, or a 1-hour safety cap.
  - `delaySec`: gap between repeats when spam is on, seconds, default 0.
- `/stop <device name>` silences it immediately and cancels any repeat in progress.

Any message that doesn't name this phone's device is ignored, so each phone only reacts to its own name.

Examples:
- `curl -d "/start pixel" ntfy.sh/nlm69` — ring until stopped
- `curl -d "/start pixel 15" ntfy.sh/nlm69` — ring once for 15 seconds
- `curl -d "/start pixel 10 y 5" ntfy.sh/nlm69` — ring 10s, pause 5s, repeat, until `/stop`

Reopen setup: `adb shell am start -n com.nlm.bytello/.MainActivity`

Build: push the zip to `main` of a repo with `.github/workflows/build.yml`; the APK is
published under Releases. Control it with the companion app Zing.
