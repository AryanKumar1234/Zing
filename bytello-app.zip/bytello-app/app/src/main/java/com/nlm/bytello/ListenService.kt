package com.nlm.bytello

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ListenService : Service() {

    companion object {
        const val ACTION_STOP_ALARM = "com.nlm.bytello.STOP_ALARM"
        const val ACTION_STOP_SERVICE = "com.nlm.bytello.STOP_SERVICE"
        const val ACTION_TEST = "com.nlm.bytello.TEST"
        const val ACTION_CLOSE_UI = "com.nlm.bytello.CLOSE_UI"
        const val CH_LISTEN = "listen"
        const val CH_ALARM = "alarm"
        const val ALARM_MAX_MS = 10 * 60 * 1000L       // cap for a single ring
        const val SPAM_MAX_MS = 60 * 60 * 1000L        // safety cap for a repeating ("spam") alarm
        const val SPAM_DEFAULT_RING_SEC = 10            // ring length per cycle if duration is omitted
    }

    @Volatile private var running = false
    @Volatile private var conn: HttpURLConnection? = null
    private var alarming = false
    private var player: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { stopAlarm() }
    @Volatile private var spamGen = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels()
        startForegroundNow()
        when (intent?.action) {
            ACTION_STOP_ALARM -> fullStop()
            ACTION_STOP_SERVICE -> {
                fullStop()
                running = false
                conn?.disconnect()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TEST -> beginStart(0, false, 0, "Test alarm")
        }
        if (!running) {
            running = true
            Thread { listenLoop() }.start()
        }
        return START_STICKY
    }

    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, "Listening", NotificationManager.IMPORTANCE_LOW)
        )
        val alarmCh = NotificationChannel(CH_ALARM, "Alarm", NotificationManager.IMPORTANCE_HIGH)
        alarmCh.setSound(null, null)
        alarmCh.setBypassDnd(true)
        alarmCh.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(alarmCh)
    }

    private fun startForegroundNow() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH_LISTEN)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Bytello service running in background")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun listenLoop() {
        var lastId: String? = null
        while (running) {
            try {
                val topic = prefs().getString("topic", "nlm69")!!.trim().ifEmpty { "nlm69" }
                val server = prefs().getString("server", "https://ntfy.sh")!!.trim().trimEnd('/')
                var url = "$server/${Uri.encode(topic)}/json"
                if (lastId != null) url += "?since=$lastId"
                val c = URL(url).openConnection() as HttpURLConnection
                conn = c
                c.connectTimeout = 15000
                c.readTimeout = 120000
                c.inputStream.bufferedReader().useLines { lines ->
                    for (line in lines) {
                        if (!running) break
                        if (line.isBlank()) continue
                        val o = JSONObject(line)
                        if (o.optString("event") == "message") {
                            lastId = o.optString("id")
                            val msg = o.optString("message", "Alarm")
                            handler.post { handleCommand(msg) }
                        }
                    }
                }
            } catch (e: Exception) {
                // network drop or timeout: fall through and reconnect
            }
            if (running) {
                try { Thread.sleep(3000) } catch (e: InterruptedException) { }
            }
        }
    }

    /**
     * Commands, space-separated:
     *   /start <device> [durationSec] [spam:y|n] [delaySec]
     *   /stop  <device>
     * durationSec: how long one ring lasts (seconds). 0 or omitted = ring until stopped
     *   (capped at ALARM_MAX_MS), unless spam is on, in which case 0 means a 10s ring.
     * spam: y repeats the ring after each gap until /stop or a 1-hour safety cap.
     * delaySec: gap between repeats when spam is on (seconds, default 0).
     * Anything that doesn't name this phone's device is ignored.
     */
    private fun handleCommand(msg: String) {
        val myDevice = (prefs().getString("device", "") ?: "").trim()
        if (myDevice.isEmpty()) return
        val parts = msg.trim().split(Regex("\\s+"))
        if (parts.size < 2) return
        val cmd = parts[0].lowercase()
        if (!parts[1].equals(myDevice, ignoreCase = true)) return

        when (cmd) {
            "/start" -> {
                val duration = parts.getOrNull(2)?.toIntOrNull() ?: 0
                val spam = parts.getOrNull(3)?.equals("y", ignoreCase = true) == true
                val delay = (parts.getOrNull(4)?.toIntOrNull() ?: 0).coerceAtLeast(0)
                beginStart(duration, spam, delay, "Alarm for $myDevice")
            }
            "/stop" -> fullStop()
        }
    }

    /** Starts a fresh ring (or spam loop), cancelling anything already in progress. */
    private fun beginStart(durationSec: Int, spam: Boolean, delaySec: Int, msg: String) {
        spamGen++
        val gen = spamGen
        stopAlarm()
        if (spam) {
            val ringSec = (if (durationSec > 0) durationSec else SPAM_DEFAULT_RING_SEC)
                .coerceAtMost((ALARM_MAX_MS / 1000).toInt())
            val deadline = System.currentTimeMillis() + SPAM_MAX_MS
            lateinit var cycle: () -> Unit
            cycle = {
                if (gen == spamGen && System.currentTimeMillis() < deadline) {
                    ring(msg, ringSec * 1000L)
                    handler.postDelayed({
                        if (gen == spamGen) {
                            stopAlarm()
                            handler.postDelayed({ cycle() }, delaySec * 1000L)
                        }
                    }, ringSec * 1000L)
                }
            }
            cycle()
        } else {
            val ringMs = if (durationSec > 0) (durationSec * 1000L).coerceAtMost(ALARM_MAX_MS) else ALARM_MAX_MS
            ring(msg, ringMs)
        }
    }

    /** Fully cancels any spam loop in progress, then silences the current ring. */
    private fun fullStop() {
        spamGen++
        stopAlarm()
    }

    private fun ring(msg: String, ringMs: Long) {
        if (alarming) return
        alarming = true

        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "zing:ring"
        ).also { it.acquire(ringMs) }

        // Alarm stream ignores the ringer/silent switch; push it to max.
        try {
            val am = getSystemService(AudioManager::class.java)
            am.setStreamVolume(
                AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0
            )
        } catch (e: Exception) { }

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setDataSource(this@ListenService, uri)
                isLooping = true
                setVolume(1f, 1f)
                prepare()
                start()
            }
        } catch (e: Exception) { }

        @Suppress("DEPRECATION")
        getSystemService(Vibrator::class.java).vibrate(
            VibrationEffect.createWaveform(longArrayOf(0, 700, 300), 0), attrs
        )

        val fs = PendingIntent.getActivity(
            this, 0,
            Intent(this, AlarmActivity::class.java)
                .putExtra("msg", msg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_STOP_ALARM),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CH_ALARM)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("ALARM")
            .setContentText(msg)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(fs, true)
            .setContentIntent(fs)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .build()
        getSystemService(NotificationManager::class.java).notify(2, n)

        handler.postDelayed(autoStop, ringMs)
    }

    private fun stopAlarm() {
        handler.removeCallbacks(autoStop)
        player?.let {
            try { it.stop() } catch (e: Exception) { }
            it.release()
        }
        player = null
        getSystemService(Vibrator::class.java).cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        getSystemService(NotificationManager::class.java).cancel(2)
        if (alarming) {
            alarming = false
            sendBroadcast(Intent(ACTION_CLOSE_UI).setPackage(packageName))
        }
    }

    override fun onDestroy() {
        running = false
        conn?.disconnect()
        stopAlarm()
        super.onDestroy()
    }
}
