# Ntfy Alarm (Android)

No interface. Open the app once: it asks for the needed permissions, starts listening to the ntfy
topic `nlm69` (change `"nlm69"` in `ListenService.kt` for another topic) and closes itself.
After that it runs in the background, restarts after every reboot, and rings a loud alarm
(alarm volume at max, works on silent) when a message arrives.

On first launch it asks for a device name. Then send these as the message to the topic:
- `/start <device name>` rings that phone loudly
- `/stop <device name>` silences it
Example: `curl -d "/start pixel" ntfy.sh/nlm69`. Any other message is ignored.

Build: push the zip to `main` of a GitHub repo with `.github/workflows/build.yml`; the APK is published under Releases.
Optional signing secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.

The launcher icon hides itself once all permissions are granted. To reopen setup:
`adb shell am start -n com.nlm.ntfyalarm/.MainActivity`
