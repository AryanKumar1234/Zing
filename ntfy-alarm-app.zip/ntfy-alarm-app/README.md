# Ntfy Alarm (Android)

Listens to an ntfy topic (default `nlm69`) and rings a loud alarm the moment a message arrives.
It plays on the **alarm** audio stream at max volume, so it rings even when the phone is on silent,
shows full-screen over the lock screen, and restarts after reboot.

## Publish the APK automatically
1. Create a GitHub repo and push this folder to the `main` branch.
2. The workflow in `.github/workflows/build.yml` builds the APK and publishes it under **Releases** on every push.
   You can also run it manually from the Actions tab.
3. Download the APK from the latest release and install it.

### Optional: stable signing key (so updates install over old versions)
```
keytool -genkey -v -keystore release.jks -alias alarm -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks
```
Add repo secrets: `KEYSTORE_BASE64` (output above), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Without them the APK is signed with a debug key, which works but changes between builds.

## First run on the phone
1. Open the app, tap **Allow permissions** until it shows "all set".
2. Tap **Start listening**.
3. Ring it: `curl -d "wake up" ntfy.sh/nlm69`

Anyone who knows the topic name can ring your phone, so pick a hard-to-guess topic.
