package com.nlm.ntfyalarm

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.EditText

/**
 * No visible UI. On launch it walks through the needed permissions one by one,
 * then starts the listener service (default topic "nlm69") and closes itself.
 */
class MainActivity : Activity() {

    private var stage = 0
    private var asking = false

    private fun notifOk() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun fsiOk() = Build.VERSION.SDK_INT < 34 ||
        getSystemService(NotificationManager::class.java).canUseFullScreenIntent()

    private fun battOk() =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    override fun onResume() {
        super.onResume()
        next()
    }

    private fun askName() {
        if (asking) return
        asking = true
        val input = EditText(this).apply {
            hint = "e.g. pixel"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Device name")
            .setMessage("Send \"/start <name>\" to the ntfy topic to ring this phone.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Save", null)
            .create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val name = input.text.toString().trim()
            if (name.isEmpty()) {
                input.error = "Enter a name"
            } else {
                getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("device", name).apply()
                dialog.dismiss()
                asking = false
                next()
            }
        }
    }

    private fun next() {
        val pkg = Uri.parse("package:$packageName")
        if (getSharedPreferences("cfg", MODE_PRIVATE).getString("device", "").isNullOrBlank()) {
            askName()
            return
        }
        if (stage == 0) {
            stage = 1
            if (!notifOk()) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                return
            }
        }
        if (stage == 1) {
            stage = 2
            if (!fsiOk()) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg))
                return
            }
        }
        if (stage == 2) {
            stage = 3
            if (!battOk()) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg))
                return
            }
        }
        if (stage == 3) {
            stage = 4
            getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("enabled", true).apply()
            startForegroundService(Intent(this, ListenService::class.java))
            // Hide the launcher icon once everything is granted (otherwise keep it so setup can be retried).
            if (notifOk() && fsiOk() && battOk()) {
                packageManager.setComponentEnabledSetting(
                    ComponentName(this, "com.nlm.ntfyalarm.Launcher"),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
            finish()
        }
    }
}
