package com.nlm.ntfyalarm

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var topic: EditText
    private lateinit var server: EditText
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = prefs()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(20))
        }
        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(Color.GRAY); setPadding(0, dp(14), 0, 0)
        }
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { onClick() }
        }

        root.addView(TextView(this).apply { text = "Ntfy Alarm"; textSize = 30f })
        root.addView(label("ntfy topic"))
        topic = EditText(this).apply { setText(p.getString("topic", "nlm69")); setSingleLine() }
        root.addView(topic)
        root.addView(label("Server"))
        server = EditText(this).apply { setText(p.getString("server", "https://ntfy.sh")); setSingleLine() }
        root.addView(server)

        root.addView(btn("Start listening") {
            saveConfig()
            prefs().edit().putBoolean("enabled", true).apply()
            startForegroundService(Intent(this, ListenService::class.java))
            Toast.makeText(this, "Listening on " + topic.text, Toast.LENGTH_SHORT).show()
            refresh()
        })
        root.addView(btn("Stop listening") {
            prefs().edit().putBoolean("enabled", false).apply()
            startService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_STOP_SERVICE))
            refresh()
        })
        root.addView(btn("Test alarm now") {
            saveConfig()
            startForegroundService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_TEST))
        })
        root.addView(btn("Allow permissions") { fixPermissions() })

        status = TextView(this).apply { textSize = 14f; setPadding(0, dp(16), 0, 0) }
        root.addView(status)
        root.addView(TextView(this).apply {
            textSize = 13f; setTextColor(Color.GRAY); setPadding(0, dp(16), 0, 0)
            text = "Send any message to your topic to ring the alarm, e.g.\ncurl -d \"wake up\" ntfy.sh/nlm69\n\n" +
                "The alarm plays on the alarm volume at maximum, so it rings even when the phone is on silent."
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun saveConfig() {
        prefs().edit()
            .putString("topic", topic.text.toString().trim().ifEmpty { "nlm69" })
            .putString("server", server.text.toString().trim().ifEmpty { "https://ntfy.sh" })
            .apply()
    }

    private fun notifOk() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun fsiOk() = Build.VERSION.SDK_INT < 34 ||
        getSystemService(NotificationManager::class.java).canUseFullScreenIntent()

    private fun battOk() = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun refresh() {
        val missing = ArrayList<String>()
        if (!notifOk()) missing.add("notifications")
        if (!fsiOk()) missing.add("full-screen alerts")
        if (!battOk()) missing.add("unrestricted battery")
        status.text = (if (prefs().getBoolean("enabled", false)) "Status: listening\n" else "Status: stopped\n") +
            (if (missing.isEmpty()) "Permissions: all set" else "Missing: " + missing.joinToString(", "))
        status.visibility = View.VISIBLE
    }

    private fun fixPermissions() {
        val pkg = Uri.parse("package:$packageName")
        when {
            !notifOk() -> requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            !fsiOk() -> startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg))
            !battOk() -> startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg))
            else -> Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refresh()
    }
}
