package com.nlm.ntfyalarm

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AlarmActivity : Activity() {

    private val closer = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) { finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#C62817"))
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "ALARM"
            textSize = 52f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = intent.getStringExtra("msg") ?: ""
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 64)
        })
        root.addView(Button(this).apply {
            text = "STOP"
            textSize = 26f
            setOnClickListener {
                startService(
                    Intent(this@AlarmActivity, ListenService::class.java)
                        .setAction(ListenService.ACTION_STOP_ALARM)
                )
                finish()
            }
        })
        setContentView(root)

        val f = IntentFilter(ListenService.ACTION_CLOSE_UI)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(closer, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(closer, f)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(closer) } catch (e: Exception) { }
        super.onDestroy()
    }
}
