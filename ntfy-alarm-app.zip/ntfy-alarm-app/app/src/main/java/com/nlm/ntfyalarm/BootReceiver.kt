package com.nlm.ntfyalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val enabled = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            .getBoolean("enabled", false)
        if (enabled) {
            context.startForegroundService(Intent(context, ListenService::class.java))
        }
    }
}
